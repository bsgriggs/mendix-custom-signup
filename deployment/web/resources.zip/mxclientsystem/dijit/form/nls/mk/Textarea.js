//>>built
define("dijit/form/nls/mk/Textarea",{iframeEditTitle:"уреди област",iframeFocusTitle:"уреди рамка на област"});
