//>>built
define("dijit/form/nls/bs/ComboBox",{previousMessage:"Prethodni izbori",nextMessage:"Još izbora"});
