//>>built
define("dijit/form/nls/eu/Textarea",{iframeEditTitle:"editatu area",iframeFocusTitle:"editatu arearen markoa"});
